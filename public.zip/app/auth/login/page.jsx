import React from 'react'
import LoginForm from "../../LoginForm"

function login() {
  return (
   <LoginForm/>
  )
}

export default login