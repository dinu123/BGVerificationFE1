// pages/admin/Companies.js
"use client"
import CustomButton from "@/common-components/CustomButton";
import Layout from "../../../admin-components/Layout"
import DashboardBody from "../../../admin-components/dashborad/Dashboardbody"
import { BsDownload, BsPlus } from "react-icons/bs";
import Link from "next/link";
import SearchComponent from "@/common-components/SearchComponent";
import DataTable from "../../../common-components/DataTable"
import * as React from 'react';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import CandidateList from "../../../admin-components/candidate/candidate-lists/CandidateLists";
// backgroundColor: "rgba(128, 128, 128, 0.3)", 
const Condidate = () => {
  return (
    <Layout>

<div className="container-fluid" style={{  minHeight: "100vh" }}>
  <div className="container">
  <div style={{ display: 'flex', justifyContent: "space-between"}}>
                <div style={{ margin: "10px" }}>
                    <SearchComponent
                        data={{
                            styles: {
                                borderRadius: '10px',
                                padding: '6px',
                                backgroundColor: 'white',
                                border: '1px solid gray',
                                width:"400px"
                               
                            }
                        }}
                    />
                </div>
                
                
                <div style={{ display: 'flex' }}>
                    <div style={{ margin: "10px" }}>
                        <CustomButton
                            text="Download as Excel"
                            icon={<BsDownload style={{ fontSize: '1.2em' }} />}
                        />
                    </div>
                    <div style={{ margin: "10px" }}>
                    <Link href="/admin/candidates/add-candidates" passHref style={{ textDecoration:"none"}}>
                <CustomButton
                    text="New Candidate"
                    icon={<BsPlus style={{ fontSize: '1.2em' }} />}
                />
            </Link>
                    </div>
                </div>
            </div>
  </div>
  {/* <DataTable/> */}
  <CandidateList/>
</div>

    </Layout>
  );
};

export default Condidate;
