import React from 'react'
import MainForm from "../../../../admin-components/mutistepForm/MainForm"

function AddCandidate() {
  return (
    <div>

<MainForm/>


    </div>
  )
}

export default AddCandidate