import React from 'react'
import NewClientForm from "../../../../admin-components/companies/NewClientForm"

function page() {
  return (
    <div>
        <NewClientForm/>

    </div>
  )
}

export default page