// pages/admin/Companies.js
"use client"
import Layout from "../../../admin-components/Layout"
import DashboardBody from "../../../admin-components/dashborad/Dashboardbody"

const Companies = () => {
  return (
    <Layout>
{/* backgroundColor: "rgba(128, 128, 128, 0.3)", */}
<div className="container-fluid" style={{  minHeight: "100vh" }}>
  <div className="container">
    <DashboardBody />
  </div>
</div>
    </Layout>
  );
};

export default Companies;
