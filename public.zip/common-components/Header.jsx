"use client"
import Logo from "./header-components/Logo"

import Account from "../common-components/Account"
import { useState } from "react";

const Header = () => {
  const [userEmail] = useState("mediatechtemple@gmail.com");
  const userInitial = userEmail.substring(0, 1);


  
  return (
    <header className="header">
      <Logo />
      <Account initials={userInitial} email={userEmail} />

      <style jsx>{`
        .header {
          background-color: #fff;
          color: #fff;
          padding: 10px 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .header-spacer {
          width: 40px; 
        }
      `}</style>
    </header>
  );
};

export default Header;
