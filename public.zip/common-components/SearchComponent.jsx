import React from 'react';

function SearchComponent({ data }) {
  
  const mergeStyles = (styles) => {
    return { ...styles };
  };

  return (
    <div className="search-container">
      <input
        type="text"
        className="form-control"
        placeholder="Search"
        style={mergeStyles(data.styles)}
      />
    </div>
  );
}

export default SearchComponent;
