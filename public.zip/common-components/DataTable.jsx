import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { IconButton, Tooltip } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility';

const columns = [
  { field: 'id', headerName: 'ID', width: 70 },
  { field: 'CandidateName', headerName: 'Candidate Name', width: 130 },
  { field: 'Designation', headerName: 'Designation', width: 130 }, // Added Designation column
  { field: 'MobileNo', headerName: 'Mobile No', width: 130 },
  { field: 'EmailID', headerName: 'Email ID', width: 130 },
  { field: 'Address', headerName: 'Address', width: 130 },
  {
    field: 'actions',
    headerName: 'Actions',
    width: 150,
    sortable: false,
    renderCell: (params) => {
      const handleEdit = () => {
        alert(`Edit ${params.row.firstName} ${params.row.lastName}`);
      };

      const handleDelete = () => {
        alert(`Delete ${params.row.firstName} ${params.row.lastName}`);
      };

      const handleView = () => {
        alert(`View ${params.row.firstName} ${params.row.lastName}`);
      };

      return (
        <>
          <Tooltip title="Edit">
            <IconButton onClick={handleEdit}>
              <EditIcon color="primary" />
            </IconButton>
          </Tooltip>
          <Tooltip title="Delete">
            <IconButton onClick={handleDelete}>
              <DeleteIcon color="secondary" />
            </IconButton>
          </Tooltip>
          <Tooltip title="View">
            <IconButton onClick={handleView}>
              <VisibilityIcon color="action" />
            </IconButton>
          </Tooltip>
        </>
      );
    },
  },
];

const rows = [
  { id: 1, CandidateName: 'Rahul Sharma', Designation: 'Software Engineer', MobileNo: '9876543210', EmailID: 'rahul@example.com', Address: 'Delhi' },
  { id: 2, CandidateName: 'Priya Singh', Designation: 'Web Developer', MobileNo: '9876543211', EmailID: 'priya@example.com', Address: 'Mumbai' },
  { id: 3, CandidateName: 'Amit Kumar', Designation: 'Data Analyst', MobileNo: '9876543212', EmailID: 'amit@example.com', Address: 'Bangalore' },
  { id: 4, CandidateName: 'Neha Patel', Designation: 'Marketing Manager', MobileNo: '9876543213', EmailID: 'neha@example.com', Address: 'Pune' },
  { id: 5, CandidateName: 'Vikas Gupta', Designation: 'Accountant', MobileNo: '9876543214', EmailID: 'vikas@example.com', Address: 'Chennai' },
  { id: 6, CandidateName: 'Shivani Reddy', Designation: 'HR Executive', MobileNo: '9876543215', EmailID: 'shivani@example.com', Address: 'Hyderabad' },
  { id: 7, CandidateName: 'Alok Mishra', Designation: 'Business Analyst', MobileNo: '9876543216', EmailID: 'alok@example.com', Address: 'Kolkata' },
  { id: 8, CandidateName: 'Pooja Gupta', Designation: 'Graphic Designer', MobileNo: '9876543217', EmailID: 'pooja@example.com', Address: 'Ahmedabad' },
  { id: 9, CandidateName: 'Ankit Verma', Designation: 'Content Writer', MobileNo: '9876543218', EmailID: 'ankit@example.com', Address: 'Jaipur' },
  { id: 10, CandidateName: 'Sneha Singh', Designation: 'Sales Manager', MobileNo: '9876543219', EmailID: 'sneha@example.com', Address: 'Lucknow' },
];

export default function DataTable() {
  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 5 },
          },
        }}
        pageSizeOptions={[5, 10, 20]}
        checkboxSelection
      />
    </div>
  );
}
