import React, { useState } from 'react';
import { IconButton, Popover, Typography } from '@mui/material';
import { FaAngleDown } from 'react-icons/fa';

const Account = ({ initials, email }) => {
  const [anchorEl, setAnchorEl] = useState(null);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);

  return (
    <div onMouseEnter={handlePopoverOpen} onMouseLeave={handlePopoverClose}>
      <IconButton sx={{ color: '#3f51b5' }}>
        {initials}
        <FaAngleDown />
      </IconButton>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handlePopoverClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
      >
        <Typography sx={{ p: 2, color: '#3f51b5' }}>
          {email}
        </Typography>
        <Typography sx={{ p: 2, backgroundColor: '#3f51b5', color: 'white', cursor: 'pointer' }} onClick={() => alert('Logout clicked')}>
  Logout
</Typography>
      </Popover>
    </div>
  );
};

export default Account;
