
const axios = require('axios');
const handleApiError = (error) => {
  console.error('API Error:', error);
  throw new Error('An error occurred while communicating with the API');
};

const BASE_URL = 'http://localhost:8000';

// Function to create a new resource
const createPost = async (endpoint, resourceData) => {
  try {
    console.log('Sending request to:', `${BASE_URL}/${endpoint}`);
    const response = await axios.post(`${BASE_URL}/${endpoint}`, resourceData);
    console.log('API Response:', response.data);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};
// Function to retrieve all resources
const getAllResources = async (endpoint) => {
  try {
    const response = await axios.get(`${BASE_URL}/${endpoint}`);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};
// Function to retrieve a single resource by ID
const getResourceById = async (endpoint, id) => {
  try {
    const response = await axios.get(`${BASE_URL}/${endpoint}/${id}`);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};
// Function to update a resource
const updateResource = async (endpoint, id, resourceData) => {
  try {
    const response = await axios.put(`${BASE_URL}/${endpoint}/${id}`, resourceData);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};
// Function to delete a resource by ID
const deleteResource = async (endpoint, id) => {
  try {
    await axios.delete(`${BASE_URL}/${endpoint}/${id}`);
    return true;
  } catch (error) {
    handleApiError(error);
  }
};

module.exports = { createPost, getAllResources, getResourceById, updateResource, deleteResource };


