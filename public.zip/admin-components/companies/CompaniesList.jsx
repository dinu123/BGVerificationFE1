// import React, { useState } from 'react';
// import { DataGrid } from '@mui/x-data-grid';
// import { IconButton } from '@mui/material';
// import { Delete, Edit, Preview } from '@mui/icons-material';
// import NewClientForm from '../../admin-components/companies/NewClientForm';

// const clientListData = [
//     {
//         id: 1,
//         category: 'Active',
//         clientCode: 'CL001',
//         clientName: 'Akash',
//         representatives: 'Ajay',
//         designation: 'Manager',
//         department: 'HR',
//         email: 'Ajay@example.com',
//         mobileNo: '1234567890',
//         Location: 'Lucknow',
//         totalReceivedCandidates: 50,
//         totalCompleteCandidatesVerification: 40,
//         totalInProcessCandidatesVerification: 10,
//         totalInsufficientCandidateData: 5,
//         totalReceivedData: 100,
//         totalPendingData: 20
//     },
//     {
//         id: 2,
//         category: 'Inactive',
//         clientCode: 'CL002',
//         clientName: 'Dinesh',
//         representatives: 'Amit',
//         designation: 'Director',
//         department: 'Finance',
//         email: 'Amit@example.com',
//         mobileNo: '9876543210',
//         Location: 'Kanpur',
//         totalReceivedCandidates: 30,
//         totalCompleteCandidatesVerification: 25,
//         totalInProcessCandidatesVerification: 5,
//         totalInsufficientCandidateData: 2,
//         totalReceivedData: 60,
//         totalPendingData: 10
//     }
// ];

// const columns = [
//     { field: 'category', headerName: 'Category', width: 150 },
//     { field: 'clientCode', headerName: 'Client Code', width: 150 },
//     { field: 'clientName', headerName: 'Client Name', width: 200 },
//     { field: 'representatives', headerName: 'Representatives', width: 200 },
//     { field: 'designation', headerName: 'Designation', width: 150 },
//     { field: 'department', headerName: 'Department', width: 150 },
//     { field: 'email', headerName: 'Email', width: 200 },
//     { field: 'mobileNo', headerName: 'Mobile No', width: 150 },
//     { field: 'Location', headerName: 'Location', width: 150 },
//     { field: 'totalReceivedCandidates', headerName: 'Total Received Candidates', width: 200 },
//     { field: 'totalCompleteCandidatesVerification', headerName: 'Total Complete Candidates Verification', width: 250 },
//     { field: 'totalInProcessCandidatesVerification', headerName: 'Total In Process Candidates Verification', width: 250 },
//     { field: 'totalInsufficientCandidateData', headerName: 'Total Insufficient Candidate Data', width: 250 },
//     { field: 'totalReceivedData', headerName: 'Total Received Data', width: 200 },
//     { field: 'totalPendingData', headerName: 'Total Pending Data', width: 200 }
// ];

// export default function CompaniesList() {
//   const [selectedClient, setSelectedClient] = useState(null);

//   const handleEditClick = (clientId) => {
//     const client = clientListData.find(client => client.id === clientId);
//     setSelectedClient(client);
//   };

//   return (
//     <div style={{ height: 400, width: '100%' }}>
//       <DataGrid
//         rows={clientListData}
//         columns={columns.concat([{ 
//           field: 'actions',
//           headerName: 'Actions',
//           width: 200,
//           renderCell: (params) => (
//             <>
//               <IconButton aria-label="edit" color="primary" onClick={() => handleEditClick(params.row.id)}>
//                 <Edit />
//               </IconButton>
//               <IconButton aria-label="delete" color="secondary">
//                 <Delete />
//               </IconButton>
//               <IconButton aria-label="preview" color="default">
//                 <Preview />
//               </IconButton>
//             </>
//           ),
//         }])}
//         pageSize={5}
//         rowsPerPageOptions={[5, 10, 20]}
       
//       />
//       {selectedClient && <NewClientForm client={selectedClient} />}
//     </div>
//   );
// }
"use client"
import React, { useEffect, useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { IconButton } from '@mui/material';
import { Delete, Edit, Preview } from '@mui/icons-material';
import NewClientForm from '../../admin-components/companies/NewClientForm';
import { getAllResources } from '@/utils/apiUtils';


export default function CompaniesList() {
  const [clientListData, setClientListData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [selectedClient, setSelectedClient] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllResources('api/companies');
        setClientListData(data);
        const dynamicColumns = Object.keys(data[0] || {}).map((key) => ({
          field: key,
          headerName: key.charAt(0).toUpperCase() + key.slice(1),
          width: 200, 
        })); 
        dynamicColumns.push({
          field: 'actions',
          headerName: 'Actions',
          width: 200,
          renderCell: (params) => (
            <>
              <IconButton aria-label="edit" color="primary" onClick={() => handleEditClick(params.row.id)}>
                <Edit />
              </IconButton>
              <IconButton aria-label="delete" color="secondary">
                <Delete />
              </IconButton>
              <IconButton aria-label="preview" color="default">
                <Preview />
              </IconButton>
            </>
          ),
        });

        setColumns(dynamicColumns);
      } catch (error) {
        console.error('Failed to fetch client data:', error);
      }
    };

    fetchData();
  }, []);

  const handleEditClick = (clientId) => {
    const client = clientListData.find(client => client.id === clientId);
    setSelectedClient(client);
  };

  return (
    <div style={{ height: 440, width: '100%' }}>
      <DataGrid
        rows={clientListData}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5, 10, 20]}
      />
      {selectedClient && <NewClientForm client={selectedClient} />}
    </div>
  );
}
