"use client"
import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { FaUser, FaEnvelope, FaMobile } from 'react-icons/fa';
import { createPost } from '../../utils/apiUtils';

const inputFields = [
    { name: 'name', placeholder: 'Name of Client', label: 'Name', type: 'text', icon: <FaUser /> },
    { name: 'representatives', placeholder: 'Name of Representatives', label: 'Representatives', type: 'text', icon: <FaUser /> },
    { name: 'designation', placeholder: 'Designation', label: 'Designation', type: 'text', icon: <FaUser /> },
    { name: 'department', placeholder: 'Department', label: 'Department', type: 'text', icon: <FaUser /> },
    { name: 'email', placeholder: 'Email ID', label: 'Email', type: 'email', icon: <FaEnvelope /> },
    { name: 'phoneNo', placeholder: 'Phone Number', label: 'Phone Number', type: 'text', icon: <FaMobile /> }
];

const NewClientForm = ({ client }) => {
    const initialValues = {
        name: client ? client.name : '',
        representatives: client ? client.representatives : '',
        designation: client ? client.designation : '',
        department: client ? client.department : '',
        email: client ? client.email : '',
        phoneNo: client ? client.phoneNo : ''
    };

    const onSubmit = async (values, { setSubmitting, resetForm }) => {
        console.log('Resource Data to be sent to API:', values);
        try {
            const result = await createPost('api/companies', values);
            console.log('Result:', result);
            resetForm(); 
        } catch (error) {
            console.error('Error saving client data:', error);
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="container-fluid" style={{ backgroundColor: "#f3f4f6", minHeight: "100vh" }}>
            <div className="row justify-content-center align-items-center" style={{ minHeight: "100vh" }}>
                <div className="col-md-6">
                    <div className="card shadow p-4" style={{ borderRadius: "20px" }}>
                        <h1 className="card-title text-center mb-4" style={{ fontWeight: 'bold', color: 'blue', fontSize: '2rem' }}>
                            {client ? 'Update Company' : 'Register New Company'}
                        </h1>
                        <Formik
                            enableReinitialize
                            initialValues={initialValues}
                            onSubmit={onSubmit}
                            validate={(values) => {
                                const errors = {};
                                inputFields.forEach(field => {
                                    if (!values[field.name]) {
                                        errors[field.name] = `${field.label} is required`;
                                    } else if (field.name === 'email' && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
                                        errors.email = 'Invalid email address';
                                    } else if (field.name === 'phoneNo' && (!/^\d{10}$/i.test(values.phoneNo) || values.phoneNo.length !== 10)) {
                                        errors.phoneNo = 'Phone number must be exactly 10 digits';
                                    }
                                });
                                return errors;
                            }}
                        >
                            {({ isSubmitting }) => (
                                <Form>
                                    {inputFields.map((field, index) => (
                                        <div key={index} className="mb-3">
                                            <div className="input-group">
                                                <span className="input-group-text" style={{ backgroundColor: '#f3f4f6' }}>{field.icon}</span>
                                                <Field
                                                    type={field.type}
                                                    name={field.name}
                                                    placeholder={field.placeholder}
                                                    className="form-control"
                                                    style={{ backgroundColor: '#f3f4f6', color: 'black', fontSize: '1rem', border: '1px solid #ced4da', borderRadius: '0.25rem' }}
                                                    maxLength={field.name === 'phoneNo' ? 10 : undefined}
                                                />
                                            </div>
                                            <ErrorMessage name={field.name} component="div" className="error-message" style={{ fontSize: '0.8rem', color: "red", marginLeft: '5px' }} />
                                        </div>
                                    ))}
                                    <div className="text-center d-flex justify-content-center">
                                        <button type="button" className="btn btn-secondary me-2" onClick={() => window.history.back()} style={{ fontSize: '1rem' }}>
                                            Back
                                        </button>
                                        <button type="submit" className="btn btn-primary" disabled={isSubmitting} style={{ fontSize: '1rem' }}>
                                            {isSubmitting ? 'Submitting...' : 'Submit'}
                                        </button>
                                    </div>

                                </Form>
                            )}
                        </Formik>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default NewClientForm;
