import React, { useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from '@mui/material';

const candidates = [
  { id: 3, vitsincoCode: 'VC003', name: 'Alice Johnson', status: 'In Sufficient', mobile: '1122334455', email: 'alice@example.com', dataReceived: '2024-01-15', dataCompleted: 50, verificationCompleted: 0, verificationCompletedDate: '' },
  // More insufficient data candidates...
];

function InsufficientDataCandidates() {
  const [open, setOpen] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const handleClickOpen = (candidate) => {
    setSelectedCandidate(candidate);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedCandidate(null);
  };

  const columns = [
    { field: 'vitsincoCode', headerName: 'Vitsinco Code', width: 130 },
    { field: 'id', headerName: 'Applicant ID', width: 130 },
    { field: 'name', headerName: 'Candidate Name', width: 150 },
    { field: 'mobile', headerName: 'Mobile No', width: 130 },
    { field: 'email', headerName: 'Email ID', width: 130 },
    { field: 'dataReceived', headerName: 'Data Received', width: 130 },
    { field: 'dataCompleted', headerName: 'Data Completed', width: 130 },
    { field: 'verificationCompleted', headerName: 'Verification Completed', width: 160 },
    { field: 'verificationCompletedDate', headerName: 'Date of Verification Completion', width: 190 },
    {
      field: 'reason',
      headerName: 'Reason',
      width: 130,
      renderCell: (params) => (
        <Button variant="outlined" onClick={() => handleClickOpen(params.row)}>Reason</Button>
      ),
    },
  ];

  return (
    <>
      <div style={{ height: 400, width: '100%' }}>
        <DataGrid
          rows={candidates}
          columns={columns}
          pageSize={5}
          rowsPerPageOptions={[5, 10, 20]}
        />
      </div>

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Reason for Insufficient Data</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {selectedCandidate ? `Reason for candidate ${selectedCandidate.name}: Missing required documents.` : ''}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

export default InsufficientDataCandidates;
