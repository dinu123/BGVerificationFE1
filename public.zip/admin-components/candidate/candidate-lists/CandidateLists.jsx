import React, { useState } from 'react';
import { Container, Tabs, Tab, Box } from '@mui/material';
import CompletedCandidates from './CompletedCandidates';
import InProcessCandidates from './InProcessCandidates';
import InsufficientDataCandidates from './InsufficientDataCandidates';
import ReceivedDataCandidates from './ReceivedDataCandidates';
import PendingDataCandidates from './PendingDataCandidates';
import DataTable from '../../../common-components/DataTable';

function CandidateList() {
  const [tab, setTab] = useState(0);

  const handleChange = (event, newValue) => {
    setTab(newValue);
  };

  return (
    <Container>
      <Tabs value={tab} onChange={handleChange}>
        <Tab label="All Candidates" />
        <Tab label="Completed" />
        <Tab label="In Process" />
        <Tab label="Insufficient Data" />
        <Tab label="Received Data" />
        <Tab label="Pending Data" />
      </Tabs>
      <Box>
        {tab === 0 && <DataTable />}
        {tab === 1 && <CompletedCandidates />}
        {tab === 2 && <InProcessCandidates />}
        {tab === 3 && <InsufficientDataCandidates />}
        {tab === 4 && <ReceivedDataCandidates />}
        {tab === 5 && <PendingDataCandidates />}
      </Box>
    </Container>
  );
}

export default CandidateList;
