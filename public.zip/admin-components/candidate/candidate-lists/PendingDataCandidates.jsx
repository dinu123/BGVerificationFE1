import React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { IconButton } from '@mui/material';
import { Email } from '@mui/icons-material';

const candidates = [
  { id: 5, vitsincoCode: 'VC005', name: 'Carol White', status: 'Pending Data', mobile: '6677889900', email: 'carol@example.com', dataReceived: '', dataCompleted: 0, verificationCompleted: 0, verificationCompletedDate: '' },
  // More pending data candidates...
];

function PendingDataCandidates() {
  const columns = [
    { field: 'vitsincoCode', headerName: 'Vitsinco Code', width: 130 },
    { field: 'id', headerName: 'Applicant ID', width: 130 },
    { field: 'name', headerName: 'Candidate Name', width: 150 },
    { field: 'mobile', headerName: 'Mobile No', width: 130 },
    { field: 'email', headerName: 'Email ID', width: 130 },
    {
      field: 'remail',
      headerName: 'Remail',
      width: 100,
      renderCell: (params) => (
        <IconButton><Email /></IconButton>
      )
    }
  ];

  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={candidates}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5, 10, 20]}
      />
    </div>
  );
}

export default PendingDataCandidates;
