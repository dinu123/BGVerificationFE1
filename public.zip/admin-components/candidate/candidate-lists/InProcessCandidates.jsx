import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { IconButton, Button } from '@mui/material';
import { Edit } from '@mui/icons-material';

const columns = [
  { field: 'vitsincoCode', headerName: 'Vitsinco Code', width: 150 },
  { field: 'id', headerName: 'Applicant ID', width: 130 },
  { field: 'name', headerName: 'Candidate Name', width: 200 },
  { field: 'mobile', headerName: 'Mobile No', width: 150 },
  { field: 'email', headerName: 'Email ID', width: 250 },
  { field: 'dataReceived', headerName: 'Data Received', width: 180 },
  { field: 'dataCompleted', headerName: 'Data Completed', width: 180 },
  { field: 'verificationCompleted', headerName: 'Verification Completed', width: 200 },
  { field: 'verificationCompletedDate', headerName: 'Date of Verification Completion', width: 230 },
  {
    field: 'edit',
    headerName: 'Edit',
    width: 100,
    sortable: false,
    renderCell: () => (
      <IconButton>
        <Edit />
      </IconButton>
    ),
  },
  {
    field: 'changeStatus',
    headerName: 'Change Status',
    width: 150,
    sortable: false,
    renderCell: () => (
      <Button variant="outlined">Change Status</Button>
    ),
  },
];

const candidates = [
    { id: 1, vitsincoCode: 'VC001', name: 'John Doe', status: 'In Process', mobile: '1234567890', email: 'john@example.com', dataReceived: '2024-01-01', dataCompleted: 75, verificationCompleted: 50, verificationCompletedDate: '2024-02-01' },
    { id: 2, vitsincoCode: 'VC002', name: 'Jane Smith', status: 'In Process', mobile: '0987654321', email: 'jane@example.com', dataReceived: '2024-01-05', dataCompleted: 100, verificationCompleted: 100, verificationCompletedDate: '2024-02-10' },
    // Add more rows as needed...
    { id: 3, vitsincoCode: 'VC003', name: 'Alice Johnson', status: 'In Process', mobile: '9876543210', email: 'alice@example.com', dataReceived: '2024-01-10', dataCompleted: 80, verificationCompleted: 70, verificationCompletedDate: '2024-02-15' },
    { id: 4, vitsincoCode: 'VC004', name: 'Bob Brown', status: 'In Process', mobile: '8765432109', email: 'bob@example.com', dataReceived: '2024-01-15', dataCompleted: 90, verificationCompleted: 80, verificationCompletedDate: '2024-02-20' },
    { id: 5, vitsincoCode: 'VC005', name: 'Charlie Davis', status: 'In Process', mobile: '7654321098', email: 'charlie@example.com', dataReceived: '2024-01-20', dataCompleted: 85, verificationCompleted: 85, verificationCompletedDate: '2024-02-25' },
    { id: 6, vitsincoCode: 'VC006', name: 'David Evans', status: 'In Process', mobile: '6543210987', email: 'david@example.com', dataReceived: '2024-01-25', dataCompleted: 95, verificationCompleted: 90, verificationCompletedDate: '2024-03-01' },
    { id: 7, vitsincoCode: 'VC007', name: 'Eve Foster', status: 'In Process', mobile: '5432109876', email: 'eve@example.com', dataReceived: '2024-01-30', dataCompleted: 80, verificationCompleted: 95, verificationCompletedDate: '2024-03-05' },
    { id: 8, vitsincoCode: 'VC008', name: 'Frank Green', status: 'In Process', mobile: '4321098765', email: 'frank@example.com', dataReceived: '2024-02-04', dataCompleted: 70, verificationCompleted: 100, verificationCompletedDate: '2024-03-10' },
    { id: 9, vitsincoCode: 'VC009', name: 'Grace Harris', status: 'In Process', mobile: '3210987654', email: 'grace@example.com', dataReceived: '2024-02-09', dataCompleted: 60, verificationCompleted: 80, verificationCompletedDate: '2024-03-15' },
    { id: 10, vitsincoCode: 'VC010', name: 'Henry Irvine', status: 'In Process', mobile: '2109876543', email: 'henry@example.com', dataReceived: '2024-02-14', dataCompleted: 50, verificationCompleted: 70, verificationCompletedDate: '2024-03-20' },
  ];
export default function InProcessCandidates() {
  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={candidates}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5, 10, 20]}
        checkboxSelection
      />
    </div>
  );
}
