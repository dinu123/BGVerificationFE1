import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';

const columns = [
  { field: 'vitsincoCode', headerName: 'Vitsinco Code', width: 150 },
  { field: 'id', headerName: 'Applicant ID', width: 130 },
  { field: 'name', headerName: 'Candidate Name', width: 200 },
  { field: 'mobile', headerName: 'Mobile No', width: 150 },
  { field: 'email', headerName: 'Email ID', width: 250 },
  { field: 'dataReceived', headerName: 'Data Received', width: 180 },
  { field: 'dataCompleted', headerName: 'Data Completed', width: 180 },
  { field: 'verificationCompleted', headerName: 'Verification Completed', width: 200 },
  { field: 'verificationCompletedDate', headerName: 'Date of Verification Completion', width: 230 },
];

const rows = [
  { id: 1, vitsincoCode: 'VC001', name: 'John Doe', mobile: '1234567890', email: 'john@example.com', dataReceived: '2024-01-01', dataCompleted: '90%', verificationCompleted: '80%', verificationCompletedDate: '2024-02-01' },
  { id: 2, vitsincoCode: 'VC002', name: 'Jane Smith', mobile: '0987654321', email: 'jane@example.com', dataReceived: '2024-01-05', dataCompleted: '100%', verificationCompleted: '100%', verificationCompletedDate: '2024-02-10' },
  { id: 3, vitsincoCode: 'VC003', name: 'Alice Johnson', mobile: '2345678901', email: 'alice@example.com', dataReceived: '2024-01-10', dataCompleted: '75%', verificationCompleted: '60%', verificationCompletedDate: '2024-02-15' },
  { id: 4, vitsincoCode: 'VC004', name: 'Bob Brown', mobile: '3456789012', email: 'bob@example.com', dataReceived: '2024-01-15', dataCompleted: '80%', verificationCompleted: '70%', verificationCompletedDate: '2024-02-20' },
  { id: 5, vitsincoCode: 'VC005', name: 'Charlie Davis', mobile: '4567890123', email: 'charlie@example.com', dataReceived: '2024-01-20', dataCompleted: '85%', verificationCompleted: '75%', verificationCompletedDate: '2024-02-25' },
  { id: 6, vitsincoCode: 'VC006', name: 'David Evans', mobile: '5678901234', email: 'david@example.com', dataReceived: '2024-01-25', dataCompleted: '90%', verificationCompleted: '80%', verificationCompletedDate: '2024-03-01' },
  { id: 7, vitsincoCode: 'VC007', name: 'Eve Foster', mobile: '6789012345', email: 'eve@example.com', dataReceived: '2024-01-30', dataCompleted: '95%', verificationCompleted: '85%', verificationCompletedDate: '2024-03-05' },
  { id: 8, vitsincoCode: 'VC008', name: 'Frank Green', mobile: '7890123456', email: 'frank@example.com', dataReceived: '2024-02-04', dataCompleted: '100%', verificationCompleted: '90%', verificationCompletedDate: '2024-03-10' },
  { id: 9, vitsincoCode: 'VC009', name: 'Grace Harris', mobile: '8901234567', email: 'grace@example.com', dataReceived: '2024-02-09', dataCompleted: '85%', verificationCompleted: '80%', verificationCompletedDate: '2024-03-15' },
  { id: 10, vitsincoCode: 'VC010', name: 'Henry Irvine', mobile: '9012345678', email: 'henry@example.com', dataReceived: '2024-02-14', dataCompleted: '90%', verificationCompleted: '85%', verificationCompletedDate: '2024-03-20' },
];

export default function CompletedCandidates() {
  return (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5, 10, 20]}
        checkboxSelection
      />
    </div>
  );
}
