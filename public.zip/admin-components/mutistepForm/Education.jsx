import React from 'react';
import TextField from '@mui/material/TextField';

const OtherReferenceInformation = ({ handleChange, formData }) => {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
      <div style={{ flex: '1 1 calc(50% - 16px)', minWidth: '300px' }}>
        <TextField
          type="text"
          name="referencePersonName"
          value={formData.referencePersonName}
          onChange={handleChange}
          label="Reference Person Name"
          variant="outlined"
          fullWidth
          margin="normal"
        />
      </div>

      <div style={{ flex: '1 1 calc(50% - 16px)', minWidth: '300px' }}>
        <TextField
          type="text"
          name="designation"
          value={formData.designation}
          onChange={handleChange}
          label="Designation"
          variant="outlined"
          fullWidth
          margin="normal"
        />
      </div>

      <div style={{ flex: '1 1 calc(50% - 16px)', minWidth: '300px' }}>
        <TextField
          type="text"
          name="companyName"
          value={formData.companyName}
          onChange={handleChange}
          label="Company Name"
          variant="outlined"
          fullWidth
          margin="normal"
        />
      </div>

      <div style={{ flex: '1 1 calc(50% - 16px)', minWidth: '300px' }}>
        <TextField
          type="text"
          name="contactNo"
          value={formData.contactNo}
          onChange={handleChange}
          label="Contact No."
          variant="outlined"
          fullWidth
          margin="normal"
        />
      </div>

      <div style={{ flex: '1 1 calc(50% - 16px)', minWidth: '300px' }}>
        <TextField
          type="email"
          name="emailID"
          value={formData.emailID}
          onChange={handleChange}
          label="Email ID"
          variant="outlined"
          fullWidth
          margin="normal"
        />
      </div>
    </div>
  );
}

export default OtherReferenceInformation;
