import React from 'react';
import { TextField } from '@mui/material';

const PermanentAddress = ({ formData, handleChange }) => {
    return (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="detailAddress"
                    value={formData.detailAddress}
                    onChange={handleChange}
                    label="Detail Address"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    label="Location"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="state"
                    value={formData.state}
                    onChange={handleChange}
                    label="State"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="durationOfStay"
                    value={formData.durationOfStay}
                    onChange={handleChange}
                    label="Duration of Stay"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="date"
                    name="from"
                    value={formData.from}
                    onChange={handleChange}
                    label="From"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="date"
                    name="to"
                    value={formData.to}
                    onChange={handleChange}
                    label="To"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                />
            </div>

            

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="select"
                    name="houseType"
                    value={formData.houseType}
                    onChange={handleChange}
                    label="House Type"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    select
                    SelectProps={{
                        native: true,
                    }}
                >
                    <option value="Owned">Owned</option>
                    <option value="Rented">Rented</option>
                    <option value="Other">Other</option>
                </TextField>
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="file"
                    name="addressProof"
                    onChange={handleChange}
                    label="Address Proof"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="file"
                    name="adharCard"
                    onChange={handleChange}
                    label="Adhar Card"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="file"
                    name="voterIdCard"
                    onChange={handleChange}
                    label="Voter ID Card"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="file"
                    name="rentAgreement"
                    onChange={handleChange}
                    label="Rent Agreement"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="courtCheck"
                    value={formData.courtCheck}
                    onChange={handleChange}
                    label="Court Check"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="policeCheck"
                    value={formData.policeCheck}
                    onChange={handleChange}
                    label="Police Check"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>
        </div>
    );
};

export default PermanentAddress;
