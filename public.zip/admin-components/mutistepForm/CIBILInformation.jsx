import React from 'react';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

const CIBILInformation = ({ handleChange, formData }) => {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
      <div style={{ flex: '1 1 calc(50% - 16px)', minWidth: '300px' }}>
      <div style={{ flex: '1 1 calc(50% - 16px)', minWidth: '300px' }}>
        <TextField
          type="text"
          name="candidateName"
          value={formData.candidateName}
          onChange={handleChange}
          label="Candidate Name"
          variant="outlined"
          fullWidth
          margin="normal"
        />
      </div>
        <TextField
          type="text"
          name="panNumber"
          value={formData.panNumber}
          onChange={handleChange}
          label="PAN Number"
          variant="outlined"
          fullWidth
          margin="normal"
        />
      </div>

      <div style={{ flex: '1 1 calc(50% - 16px)', minWidth: '300px' }}>
        <TextField
          type="file"
          name="panUpload"
          onChange={handleChange}
          label="Upload PAN Card"
          variant="outlined"
          fullWidth
          margin="normal"
          InputLabelProps={{
            shrink: true,
          }}
        />
      </div>

      
    </div>
  );
}

export default CIBILInformation;
