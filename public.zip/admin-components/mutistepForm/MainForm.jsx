// "use client";
// import { useState } from 'react';
// import GeneralInformation from "./GeneralInformation";
// import Education from "./Education";
// import PermanentAddress from './PermanentAddress';

// const MainForm = () => {
//     const [data, setData] = useState({
//         name: "",
//         email: "",
//         dob: "",
//         gender: "male",
//         address: "",
//         education: [{
//             candidateName: '',
//             courseName: '',
//             institutionName: '',
//             institutionAddress: '',
//             universityName: '',
//             yearOfPassing: '',
//             rollNo: '',
//             markGradeClass: '',
//             marksheetCertificate: ''
//         }]
//     });

//     const handleChange = (event, index = null) => {
//         const { name, value, files } = event.target;
//         if (index !== null) {
//             const updatedEducation = [...data.education];
//             updatedEducation[index][name.split('-')[0]] = files ? files[0] : value;
//             setData({
//                 ...data,
//                 education: updatedEducation
//             });
//         } else {
//             setData({
//                 ...data,
//                 [name]: value,
//             });
//         }
//     };

//     const addEducation = () => {
//         setData({
//             ...data,
//             education: [...data.education, {
//                 candidateName: '',
//                 courseName: '',
//                 institutionName: '',
//                 institutionAddress: '',
//                 universityName: '',
//                 yearOfPassing: '',
//                 rollNo: '',
//                 markGradeClass: '',
//                 marksheetCertificate: ''
//             }]
//         });
//     };

//     const removeEducation = (index) => {
//         const updatedEducation = data.education.filter((_, i) => i !== index);
//         setData({ ...data, education: updatedEducation });
//     };

//     const [activeTab, setActiveTab] = useState(0);

//     const formElements = [
//         <GeneralInformation key="userNameEmail" data={data} handleChange={handleChange} />,
//         <PermanentAddress key="address" data={data} setData={setData} />,
//         <Education key="Education" data={data} handleChange={handleChange} addEducation={addEducation} removeEducation={removeEducation} />,

//     ];

//     return (
//         <div>
//             <div>
//                 {formElements[activeTab]}
//             </div>
//             <div>
//                 <button
//                     disabled={activeTab === 0}
//                     onClick={() => setActiveTab(prev => prev - 1)}
//                 >
//                     Back
//                 </button>
//                 <button
//                     disabled={activeTab === formElements.length - 1}
//                     onClick={() => setActiveTab(prev => prev + 1)}
//                 >
//                     Next
//                 </button>
//                 {activeTab === formElements.length - 1 &&
//                     <button onClick={() => console.log(data)}>Submit</button>
//                 }
//             </div>
//         </div>
//     );
// };

// export default MainForm;

// pages/index.js
"use client"
import React, { useState } from 'react';
import { Stepper, Step, StepLabel, Button, TextField } from '@mui/material';
import Education from "./Education"
import GeneralInformation from "./GeneralInformation"
import PermanentAddress from "./PermanentAddress"
import WorkExperience from "./WorkExperience"
import FathersDocument from "./FathersDocument"
import CIBILInformation from "./CIBILInformation"
import OtherReferenceInformation from "./OtherReferenceInformation"

const MainForm = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    address: '',
  });

  const [activeStep, setActiveStep] = useState(0);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleNext = () => {
    setActiveStep((prevStep) => prevStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleSubmit = () => {
    console.log(formData); // Replace with actual submit logic
  };

  return (
    <div style={{  margin: '20px' }}>
      <Stepper activeStep={activeStep} alternativeLabel>
        <Step>
          <StepLabel>General Information</StepLabel>
        </Step>
        <Step>
          <StepLabel>Permanent Address</StepLabel>
        </Step>
        <Step>
          <StepLabel>Education</StepLabel>
        </Step>
        <Step>
          <StepLabel>Work Experience</StepLabel>
        </Step>
        <Step>
          <StepLabel>Fathers Document</StepLabel>
        </Step>
        <Step>
          <StepLabel>CIBIL Information</StepLabel>
        </Step>
        <Step>
          <StepLabel>Other Information</StepLabel>
        </Step>
        
      </Stepper>

      {activeStep === 0 && (
         <GeneralInformation handleChange={handleChange} formData={formData} />

  
)}

      {activeStep === 1 && (
        <div>
          <div>
          <PermanentAddress handleChange={handleChange} formData={formData} />

        
        </div>
          
          {/* Other form fields for Step 2 */}
        </div>
      )}

      {activeStep === 2 && (
        <div>
         <Education handleChange={handleChange} formData={formData} />
        </div>
      )}

      {activeStep === 3 && (
        
        <div>
          <WorkExperience handleChange={handleChange} formData={formData} />
        </div>
      )}

      {activeStep === 4 && (
       <div>
       <FathersDocument handleChange={handleChange} formData={formData} />
     </div>
      )}
      {activeStep === 5 && (
       <div>
       <CIBILInformation handleChange={handleChange} formData={formData} />
     </div>
      )}
       {activeStep === 6 && (
       <div>
       <OtherReferenceInformation handleChange={handleChange} formData={formData} />
     </div>
      )}
     

      <div style={{ marginTop: '20px' }}>
        <Button
          disabled={activeStep === 0}
          onClick={handleBack}
          variant="outlined"
          style={{ marginRight: '10px' }}
        >
          Back
        </Button>
        <Button
          disabled={activeStep === 6} // Adjust based on number of steps
          onClick={handleNext}
          variant="contained"
        >
          Next
        </Button>
        {activeStep === 6 && (
          <Button
            onClick={handleSubmit}
            variant="contained"
            color="primary"
            style={{ marginLeft: '10px' }}
          >
            Submit
          </Button>
        )}
      </div>
    </div>
  );
};

export default MainForm;

