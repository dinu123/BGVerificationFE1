import React from 'react';
import { TextField } from '@mui/material';

const GeneralInformation = ({ formData, handleChange }) => {
    return (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="select"
                    name="candidate"
                    value={formData.candidate}
                    onChange={handleChange}
                    label="E mail Notification to candidate"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    select
                    SelectProps={{
                        native: true,
                    }}
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </TextField>
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="select"
                    name="client"
                    value={formData.client}
                    onChange={handleChange}
                    label="E mail Notification to client"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    select
                    SelectProps={{
                        native: true,
                    }}
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </TextField>
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="select"
                    name="admin"
                    value={formData.admin}
                    onChange={handleChange}
                    label="E mail Notification to admin"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    select
                    SelectProps={{
                        native: true,
                    }}
                >
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </TextField>
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    label="Company (Auto Assign to Client Portal)"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="candidateName"
                    value={formData.candidateName}
                    onChange={handleChange}
                    label="Candidate Name"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="applicantId"
                    value={formData.applicantId}
                    onChange={handleChange}
                    label="Applicant ID / Employee Code"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="candidateFatherName"
                    value={formData.candidateFatherName}
                    onChange={handleChange}
                    label="Candidate Father’s Name"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="date"
                    name="candidateDOB"
                    value={formData.candidateDOB}
                    onChange={handleChange}
                    label="Candidate DOB"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="candidateMobileNo"
                    value={formData.candidateMobileNo}
                    onChange={handleChange}
                    label="Candidate Mobile No"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="email"
                    name="candidateEmail"
                    value={formData.candidateEmail}
                    onChange={handleChange}
                    label="Candidate Email ID"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="companyProcessName"
                    value={formData.companyProcessName}
                    onChange={handleChange}
                    label="Company Process Name"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="companyLocation"
                    value={formData.companyLocation}
                    onChange={handleChange}
                    label="Company Location"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="text"
                    name="verificationChecks"
                    value={formData.verificationChecks}
                    onChange={handleChange}
                    label="Assign Verification Checks"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                />
            </div>

            <div style={{ flex: '1 1 calc(25% - 16px)', minWidth: '200px' }}>
                <TextField
                    type="date"
                    name="caseReceivedOn"
                    value={formData.caseReceivedOn}
                    onChange={handleChange}
                    label="Case Received on"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{
                        shrink: true,
                    }}
                />
            </div>
        </div>
    );
};

export default GeneralInformation;
